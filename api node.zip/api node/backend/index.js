const express  =  require('express');
const order = require('./models/order');
const orderitem = require('./models/orderitem');
const user = require('./models/user');
const app = express();

app.get('/',(req,res) =>{
    res.send("OK")
})



app.post('/orders',(req,res) =>{
    order.create(req.body,
        {include:[orderitem]
        })
    .then( o =>{
        res.send(o.dataValues);
    })
})


app.put('/orders/:id',(req,res) =>{
    order.findByPk(req.params.id,
        {
            //include:[user,orderitem,orderitem.product]
            include:[user,
                { association: order.orderItems,
                    include: [orderitem.product]
                }]
        })
        .then( o =>{
            res.send(o.dataValues);
        })
})



app.post('/orders',(req,res) =>{
    order.create(req.body.name)
    .then( o =>{
        res.send(o.dataValues);
    })
})

app.put('/orders/:id',(req,res) =>{
    order.findByPk(req.params.id)
    .then( o =>{
        o.update(req.body).then((order)=>
        {
            res.send(order)
        })
    })
})

app.listen(3000,()=>{
    console.log("executando na porta 3000")
})

//Order.findByPk(id,{include:[User]}).then(0 => o.dataValues)
//Order.create({status: "novo"}).then(0 =>User.findByPk(idUser).then(0 => o.setUser(u)))