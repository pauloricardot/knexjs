// Update with your config settings.
require('dotenv').config();
module.exports = {
  // staging: {
  //   client: 'postgresql',
  //   connection: {
  //     database: 'parceiro5',
  //     user:     'postgres',
  //     password: 'root'
  //   },
  //   pool: {
  //     min: 2,
  //     max: 10
  //   },
  //   migrations: {
  //     tableName: 'knex_migrations',
  //     directory: `${__dirname}/src/database/migrations`
  //   }
  // },
  development: {
    client: 'mysql',
    connection: {
      host : '127.0.0.1',
      user : 'root',
      password : '',
      database : 'parceiro1'
    },
    migrations: {
      directory: './src/database/migrations',
    },
    seeds: { directory: './data/seeds' },
  },

  // testing: {
  //   client: 'pg',
  //   connection: process.env.DB_URL,
  //   migrations: {
  //     directory: './data/migrations',
  //   },
  //   seeds: { directory: './data/seeds' },
  // },

  // production: {
  //   client: 'pg',
  //   connection: process.env.DB_URL,
  //   migrations: {
  //     directory: './data/migrations',
  //   },
  //   seeds: { directory: './data/seeds' },
  // },
};
